# _*_ coding : utf-8 _*_
# @Time : 2023/11/8 21:56
# @Author : Liu kebing
# @File : construct_dataset_CG
# @Project : HGNN try1

import pandas as pd
import numpy as np


data_dir = r"C:\Users\liuke\chatgpt话题热度按周预测\代码\3-7月话题微博特征和总数.csv"
data = pd.read_csv(data_dir)

